package com.example.MIcroservicio.service;



import com.example.MIcroservicio.model.User;

import java.util.List;

public interface IUserService {

   /* public List<User> listAllUsers();
    public User saveUser(User user);
    public User findByIdUser(Long id);
    public User updateUserById(User user, Long id);
    public void deleteUserById(Long id);*/


}

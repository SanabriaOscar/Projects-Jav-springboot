package com.example.MIcroservicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MIcroservicioDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

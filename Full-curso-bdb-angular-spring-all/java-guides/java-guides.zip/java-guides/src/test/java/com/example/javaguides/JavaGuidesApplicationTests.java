package com.example.javaguides;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaGuidesApplicationTests {

	@Test
	void contextLoads() {
	}

}

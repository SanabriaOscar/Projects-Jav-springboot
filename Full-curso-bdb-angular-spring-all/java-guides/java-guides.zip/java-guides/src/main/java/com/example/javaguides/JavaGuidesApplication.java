package com.example.javaguides;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaGuidesApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaGuidesApplication.class, args);
	}

}

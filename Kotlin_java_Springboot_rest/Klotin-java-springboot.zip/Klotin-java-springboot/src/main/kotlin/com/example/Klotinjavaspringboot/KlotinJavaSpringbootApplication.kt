package com.example.Klotinjavaspringboot

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class KlotinJavaSpringbootApplication

fun main(args: Array<String>) {
	runApplication<KlotinJavaSpringbootApplication>(*args)
}

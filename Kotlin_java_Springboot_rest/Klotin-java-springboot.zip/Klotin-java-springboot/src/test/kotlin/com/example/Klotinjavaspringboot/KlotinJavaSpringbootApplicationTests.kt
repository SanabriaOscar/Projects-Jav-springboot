package com.example.Klotinjavaspringboot

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class KlotinJavaSpringbootApplicationTests {

	@Test
	fun contextLoads() {
	}

}
